Revia for Windows — v1.5.0 Beta
================================

Thank you for testing Revia for Windows!

QUICK START:
1. Double-click Revia.exe to launch.
2. Complete the initial setup.
3. Use Alt+Space to summon Revia from anywhere.
4. Type your query or use voice search.
5. Press Escape to dismiss.

NOTE ON WINDOWS SMARTSCREEN:
Because this is an early beta release without an enterprise certificate,
Windows Defender SmartScreen may display an informational notice.
Click "More info" and "Run anyway" to open Revia.

SYSTEM TRAY:
Revia runs in your background tray (near the system clock). Right-click
the tray icon anytime to open settings, pause indexing, or quit.

Support & Updates: https://github.com/Samraatsharma/doclify
